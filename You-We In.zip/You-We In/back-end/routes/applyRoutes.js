const express = require('express');
const applyRoutes = express.Router();
let Apply = require('../models/apply.model');

applyRoutes.route('/').get(function(req,res){
    Apply.find(function(err,apply){
        if(err){
            console.log(err);
        }
        else{
            res.json(apply); 
        }
    })
})

applyRoutes.route('/add').post(function(req,res){
  let apply = new Apply(req.body);
  apply.save()
  .then(apply =>{
      res.status(200).json({'apply':'Applied successfully'})
  })
  .catch(err =>{
      res.status(400).send('applying new job failed');
  
  })
})


module.exports = applyRoutes;