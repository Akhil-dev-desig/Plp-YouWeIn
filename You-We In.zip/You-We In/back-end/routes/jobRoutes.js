const express = require('express');
const jobRoutes = express.Router();
let Job = require('../models/job.model');

jobRoutes.route('/').get(function(req,res){
    Job.find(function(err,jobs){
        if(err){
            console.log(err);
        }
        else{
            res.json(jobs); 
        }
    })
})

jobRoutes.route('/add').post(function(req,res){
  let job = new Job(req.body);
  job.save()
  .then(job =>{
      res.status(200).json({'job':'job added successfully'})
  })
  .catch(err =>{
      res.status(400).send('adding new job failed');
  
  })
})

jobRoutes.route('/delete/:id')
.get(function(req,res){
  Job.deleteOne({_id:req.params.id},function(err,job){
      if(err) res.json(err);
      else res.json({
          message: 'Successfully removed',
          job:job
      });
  });
});

module.exports = jobRoutes;