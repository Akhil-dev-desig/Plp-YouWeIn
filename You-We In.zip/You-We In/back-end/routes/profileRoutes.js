const express = require('express');
const profileRoutes = express.Router();
let Profile = require('../models/profile.model');

profileRoutes.route('/').get(function(req,res){
    Profile.find(function(err,profile){
        if(err){
            console.log(err);
        }
        else{
            res.json(profile); 
        }
    })
})
profileRoutes.route('/:id').get(function(req,res){
  let id = req.params.id;
  Profile.findById(id,function(err,profile){
      res.json(profile);
  });
});

profileRoutes.route('/update/:id').post(function(req,res){
  Profile.findById(req.params.id,function(err,profile){
      if(!profile)
      res.status(404).send("data is not found");
      else
      profile.firstName = req.body.firstName;
      profile.lastName = req.body.lastName;
      profile.qualification = req.body.qualification;
      profile.recentlyWorked = req.body.recentlyWorked;
      profile.experience = req.body.experience;
      profile.email = req.body.email;
      profile.contactNumber = req.body.contactNumber;
      profile.save().then(profile =>{
          res.json('Profile Updated');
      })
      .catch(err =>{
          res.status(404).send("Update not possible");
      });
  });
});

profileRoutes.route('/delete/:id')
.get(function(req,res){
  Profile.deleteOne({_id:req.params.id},function(err,profile){
      if(err) res.json(err);
      else res.json({
          message: 'Successfully removed',
          profile:profile
      });
  });
});

profileRoutes.route('/add').post(function(req,res){
  let profile = new Profile(req.body);
  console.log(profile);
   profile.save().then(profile =>{
      res.json({'profile':'profile added successfully'})
  })
  .catch(err =>{
      res.status(400).send('adding new profile failed');
  
  })
})

module.exports = profileRoutes;