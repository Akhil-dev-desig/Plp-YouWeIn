const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let Profile = new Schema({
    firstName:{
        type:String
    },
    lastName:{
        type:String
    },
    qualification:{
        type:String
    },
    recentlyWorked:{
        type:String
    },
    experience:{
        type:String
    },
    email:{
        type:String
    },
    contactNumber:{
        type:String
    }
});

module.exports = mongoose.model('Profile',Profile);