const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let Apply = new Schema({
    resume:{
        type:String
    }
   
});

module.exports = mongoose.model('Apply',Apply);