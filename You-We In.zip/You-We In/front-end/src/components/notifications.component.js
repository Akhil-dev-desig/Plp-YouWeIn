import React, { Component } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import Swal from 'sweetalert2';
import '../App.css';
import NavBar2 from './navBar2.component';

import {Icon} from 'semantic-ui-react'


class User extends Component {
    constructor(props) {
        super(props);

    }

    

    render() {
        return (
           <div>
                <div>
               


            </div>
               <br/>
                <div className="div-box container ">
                <b>You applied Job Successfully</b>
           <tr>
                <td><b>Resume:</b> {this.props.user.resume}</td></tr>
               
              
             

               </div>
            
                </div>
        
        )
    }
}
export default class Notifications extends Component {
    constructor(props) {
        super(props);
        this.state = { applies: [], id: '' };

        // this.onChangeProductName = this.onChangeProductName.bind(this);
        // this.onChangeProductCost = this.onChangeProductCost.bind(this);
        //binding onSubmit event
        // this.onSubmit = this.onSubmit.bind(this);
        // this.clearForm = this.clearForm.bind(this);


    }
    //life cycle hook
    componentDidMount() {
        axios.get('http://localhost:4000/applies')
            .then(response => {
                this.setState({ applies: response.data });
            })
            .catch(function (error) {
                console.log(error);
            })
    }
    userList() {
        return this.state.applies.map(function (currentUser, i) {
            return <User user={currentUser} key={i} />;
        })
    }

    render() {
        return (
            <div>

    <NavBar2/>

            <div className="container">
                <div className="row">
                    <div className="col-lg-6" style={{ marginTop: 20 }} >
                        <h3 className="text-left text-primary">Job Notifications </h3>
                        <table className="table table-stripped"
                            style={{ marginTop: 20 }} >
                         
                            <tbody>
                                {this.userList()}

                            </tbody>
                        </table>
                    </div>
                 
              
                </div>
            </div>
            </div>
    )
    }
}

