import { BrowserRouter as Router, Route, Link } from 'react-router-dom';
import React, { Component } from 'react';
import NavBar2 from './navBar2.component';
import axios from 'axios';
import Post from './post.component';
import Swal from 'sweetalert2';
import '../App.css'


class User extends Component {
    constructor(props) {
        super(props);
        this.state = {
            resume: ''
        }
        // this.applyUser = this.applyUser.bind(this);
        this.onChangeResume = this.onChangeResume.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
    }

    onChangeResume(event) {
        this.setState({
            resume: event.target.value
        });
    }
    // applyUser() {

    //     let result =
    //         Swal.fire('Do you want to Apply for this job?');

    //     if (result) {

    //         Swal.fire({
    //             title: 'Are you sure want to Apply?',

    //             type: 'warning',
    //             showCancelButton: true,
    //             confirmButtonColor: '#3085d6',
    //             cancelButtonColor: '#d33',
    //             confirmButtonText: 'Yes, Apply!'
    //         }).then((result) => {
    //             if (result.value) {
    //                 Swal.fire(
    //                     'Applied!',
    //                     'You applied for this job.',
    //                     'success'
    //                 )
    //             }
    //         })
    //             .then(console.log('Applied Successfully'))
    //             .catch(err => console.log(err))
    //     }
    // }
    onSubmit(event) {
        event.preventDefault();

        const newResume = {
            resume: this.state.resume,
        }

        //for mongodb
        axios.post('http://localhost:4000/uploads/add', newResume)
            .then(res => console.log(res.data));

        this.setState({
            resume: ''
        })
        alert('applied successfully');
        window.location.reload();
        this.props.history.push('/newsfeed');
    }
    render() {
        return (
            <div>

                <br />
                <center>
                    <div className="div-table container ">
                        <h1>Job Alert</h1>
                        <tr>
                            <td><b>Company Name/Business:</b> {this.props.user.companyName}</td></tr>
                        <tr>
                            <td><b>Location:</b> {this.props.user.location}</td></tr>
                        <tr>
                            <td><b>Role: </b> {this.props.user.role}</td></tr>
                        <tr>
                            <td> <b>Skills :</b>{this.props.user.skills}</td></tr>
                        <tr><td><b>Experience:</b> {this.props.user.experience}</td></tr>
                        <tr><td><b>Email:</b>{this.props.user.email}</td></tr>
                        <tr>  <td><b>Contact Number:</b>{this.props.user.contactNumber}</td></tr>
                        <tr>
                            <td>

                                &nbsp;  &nbsp;
                   <label><b>Upload Resume:</b></label> &nbsp; &nbsp;
                    <input type="file" accept="image/jpg"
                                    onChange={this.onChangeResume} required value={this.state.resume} name="resume" id="resume" required />
                            </td></tr>

                        <td>
                            <button onClick={this.onSubmit} className="btn btn-success">Apply</button>
                        </td>
                    </div></center>
            </div>
        )
    }
}
export default class Newsfeed extends Component {
    constructor(props) {
        super(props);
        this.state = { jobs: [], id: '' };
    }
    //life cycle hook
    componentDidMount() {
        axios.get('http://localhost:4000/jobs')
            .then(response => {
                this.setState({ jobs: response.data });
            })
            .catch(function (error) {
                console.log(error);
            })
    }
    userList() {
        return this.state.jobs.map(function (currentUser, i) {
            return <User user={currentUser} key={i} />;
        })
    }
    notification() {
        alert('connected successfully')
    }


    render() {
        return (
            <div>
               <NavBar2/>
                            <Post />

                            <table className="table" style={{ width: 400 }}
                                style={{ marginTop: 20 }}>


                                {this.userList()}

                            </table><br />


                        </div>
                        )
                    }
}