import React, { Component } from 'react';
import axios from 'axios';
import NavBar from './nav.component';
import Myprofile from './myprofile.component';
import '../App.css';
 

export default class Editprofile extends Component {
    constructor(props) {
        super(props);

        //binding text box onChange events
        this.onChangeFirstName = this.onChangeFirstName.bind(this);
        this.onChangeLastName = this.onChangeLastName.bind(this);
        this.onChangeQualification = this.onChangeQualification.bind(this);
        this.onChangeLastName = this.onChangeLastName.bind(this);
        this.onChangeRecentlyWorked = this.onChangeRecentlyWorked.bind(this);
        this.onChangeExperience = this.onChangeExperience.bind(this);
        this.onChangeEmail = this.onChangeEmail.bind(this);
        this.onChangeContactNumber = this.onChangeContactNumber.bind(this);
        //binding onSubmit event
        this.onSubmit = this.onSubmit.bind(this);

        this.state = {
            firstName: '',
            lastName: '',
            qualification: '',
            recentlyWorked: '',
            experience: '',
            email: '',
            contactNumber: ''


        }

    } //end of constructor
    componentDidMount() {
        axios.get('http://localhost:4000/profile/'
        + this.props.match.params.id)
        .then(response => {
            this.setState({ 
                firstName:  response.data.firstName,
                lastName:  response.data.lastName,
                qualification:  response.data.qualification,
                recentlyWorked: response.data.recentlyWorked,
                experience: response.data.experience,
                email:  response.data.email,
                contactNumber:  response.data.contactNumber,
              
            });
        })
        .catch(function (error) {
            console.log(error);
        })
    }
    onChangeFirstName(event) {
        this.setState({
            firstName: event.target.value
        });
    }
    onChangeLastName(event) {
        this.setState({
            lastName: event.target.value
        });
    }
    onChangeQualification(event) {
        this.setState({
            qualification: event.target.value
        });
    }
    onChangeRecentlyWorked(event) {
        this.setState({
            recentlyWorked: event.target.value
        });
    }
    onChangeExperience(event) {
        this.setState({
            experience: event.target.value
        });
    }
    onChangeEmail(event) {
        this.setState({
            email: event.target.value
        });
    }
    onChangeContactNumber(event) {
        this.setState({
            contactNumber: event.target.value
        });
    }

    onSubmit(event) {
        event.preventDefault();

        const obj = {
            firstName: this.state.firstName,
            lastName: this.state.lastName,
            qualification: this.state.qualification,
            recentlyWorked: this.state.recentlyWorked,
            experience: this.state.experience,
            email: this.state.email,
            contactNumber: this.state.contactNumber,
        }
        console.log(obj);
        axios.post('http://localhost:4000/profile/update/'+
        this.props.match.params.id, obj)
        .then(res => console.log(res.data));

        this.props.history.push('/myprofile');
        window.location.reload();
    }
    render() {
        return (
            <div>
               
                
            
            <Myprofile/>
                    
                  
                        <div className=" col-lg-6">
                            <div style={{ marginTop: 10 }}>
                                <h3 className="text-primary">Update Profile</h3><br />
                                <form onSubmit={this.onSubmit}>

                                    <div className="form-group">

                                        <label>First Name</label>
                                        <input type="text"
                                            className="form-control"
                                            value={this.state.firstName}
                                            onChange={this.onChangeFirstName} />

                                    </div>

                                    <div className="form-group">
                                        <label>Last Name :</label>
                                        <input type="text"
                                            className="form-control"
                                            value={this.state.lastName}
                                            onChange={this.onChangeLastName} />
                                    </div>
                                    <div className="form-group">
                                        <label>Qualification :</label>
                                        <input type="text"
                                            className="form-control"
                                            value={this.state.qualification}
                                            onChange={this.onChangeQualification} />
                                    </div>
                                    <div className="form-group">
                                        <label>Recently Worked :</label>
                                        <input type="text"
                                            className="form-control"
                                            value={this.state.recentlyWorked}
                                            onChange={this.onChangeRecentlyWorked} />
                                    </div>
                                    <div className="form-group">
                                        <label>Experience :</label>
                                        <input type="text"
                                            className="form-control"
                                            value={this.state.experience}
                                            onChange={this.onChangeExperience} />
                                    </div>
                                    <div className="form-group">
                                        <label>Email :</label>
                                        <input type="text"
                                            className="form-control"
                                            value={this.state.email}
                                            onChange={this.onChangeEmail} />
                                    </div>
                                    <div className="form-group">
                                        <label>Contact Number :</label>
                                        <input type="text"
                                            className="form-control"
                                            value={this.state.contactNumber}
                                            onChange={this.onChangeContactNumber} />
                                    </div>






                                    <div className="form-group">
                                        <input type="submit" value="Update Profile"
                                            className="btn btn-success" />&nbsp;&nbsp;
                         <button type="button" onClick={this.clearForm}
                                            className="btn btn-danger" >Clear </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                   
                    <hr />
                  
                    </div>
               
        )
    }
}