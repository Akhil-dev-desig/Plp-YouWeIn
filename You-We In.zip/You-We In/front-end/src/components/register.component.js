// import React from 'react';
// import axios from 'axios';
// import NavBar from './nav.component';
// export default class Register extends React.Component {
//     constructor(props) {
//         super(props);
//         this.state = {
//             fields: {
//                 firstName: '',
//                 lastName: '',
//                 email: '',
//                 password: ''
//             },
//             errors: {},
//             formIsValid: true
//         }
//         // COMMON ONCHANGE HANDLER FOR BOTH THE TEXT FIELDS
//         this.handleChange = this.handleChange.bind(this);

//         // this.clearForm =  this.clearForm.bind(this);
//         // this.state={
//         //     firstName:"",
//         //     lastName:"",
//         //     email:"",
//         //     password:""
//         //  }
//     }

//     handleChange(e) {
//         let fields = this.state.fields;
//         // accessing input boxes values with their names and storing in fields
//         fields[e.target.name] = e.target.value;
//         this.setState({
//             fields: fields
//         });
//         console.log(this.state.fields);
//     }

//     // submitRegisterForm(e) 
//     // {
//     //     e.preventDefault();



//     //     axios.post('http://localhost:4000/users/add',newUser).then(res => console.log(res.data));

//     //     this.setState({
//     //         firstName: '',
//     //         lastName: '',
//     //         email: '',
//     //         password: false
//     //     })

//     //     // redirecting to home component
//     //     // this.props.history.push('/login');
//     getRegister = (e) => {
//         e.preventDefault();
//         const newUser ={
//             firstName: this.state.firstName,
//             lastName: this.state.lastName,
//            email: this.state.email,
//            password:this.state.password
//         };
//         axios.post('http://localhost:4000/users/register', newUser).then(res => {

//             console.log(res.data);
//             window.alert("You Have successfully registered");

//             window.location = '/user/login';

//         })
//             // .catch(err => {
//             //     console.log(err)
//             //     console.error(err.response);
//             //     var errors = err.response.data.errors === undefined ? [] : err.response.data.errors;

//             //     for (var i = 0; i < errors.length; i++) {
//             //         this._addNotification("error", `${i + 1} -> ${errors[i].param}: ${errors[i].msg}`)
//             //     }


//             // });



//         if (this.validateForm()) {
//             if (this.state.fields) {
//                 let fields = {};
//                 fields["firstName"]="";
//                 fields["lastName"]="";
//                 fields["email"] = "";
//                 fields["password"] = "";
//                 this.setState({ fields: fields });
//                 alert("Registered Succesfully");
//                 this.props.history.push('/login');
//             }
//             else {
//                 alert("Invalid Credentials ..!");
//             }
//         }
//     }


//     // validation for form fields
//     validateForm() {
//         let fields = this.state.fields;
//         let errors = {};
//         let formIsValid = true;
//         // FirstName
//         if (!fields["firstName"]) {
//             formIsValid = false;
//             errors["firstName"] = "Cannot be empty";
//         }

//        else if (typeof fields["firstName"] !== "undefined") {
//             if (!fields["firstName"].match(/^[a-zA-Z]+$/)) {
//                 formIsValid = false;
//                 errors["firstName"] = "Only letters";
//             }
//         }
//         // LastName
//         if (!fields["lastName"]) {
//             formIsValid = false;
//             errors["lastName"] = "Cannot be empty";
//         }

//         else if (typeof fields["lastName"] !== "undefined") {
//             if (!fields["lastName"].match(/^[a-zA-Z]+$/)) {
//                 formIsValid = false;
//                 errors["lastName"] = "Only letters";
//             }
//         }

//         // Email
//         if (!fields["email"]) {
//             formIsValid = false;
//             errors["email"] = "Please enter your Email ID";
//         }
//         else if (typeof fields["email"] !== "undefined") {
//             if (!(fields["email"].match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i))) {
//                 formIsValid = false;
//                 errors["email"] = "Please enter Valid Email-Id";
//             }
//         }
//         else {
//             errors["email"] = "";
//         }
//         // Password
//         if (!fields["password"]) {
//             formIsValid = false;
//             errors["password"] = "Please enter your Password";
//         }
//         else if (typeof fields["password"] !== "undefined") {
//             if (!(fields["password"].length >= 6)) {
//                 formIsValid = false;
//                 errors["password"] = "Password is too short";
//             }
//         }
//         else {
//             errors["password"] = "";
//         }

//         this.setState({
//             errors: errors,
//             formIsValid: formIsValid
//         });

//         return formIsValid;
//     }

//     // clearForm(e){
//     //     e.preventDefault();
//     //     this.setState({
//     //        firstName:"",
//     //        lastName:"",
//     //        email:"",
//     //        password:""
//     //     })
//     // }
//     render() {
//         return (
//             <div>
//                 <NavBar />
//                 <div className="container" style={{marginTop:30}}>
//                     <div className="row">
//                         <div className="offset-lg-3 col-lg-6">
//                             <h3 className="text-primary">Register</h3>
//                             <form onSubmit={this.getRegister}>

//                                 <div className="form-group">

//                                     <label> First Name: </label>
//                                     <input type="text" className="form-control" name="firstName"
//                                         value={this.state.fields.firstName}
//                                          onChange={this.handleChange} />

//                                     <div className={this.state.errors.firstName ? 'alert alert-danger' : ''}>{this.state.errors.firstName}
//                                     </div>
//                                 </div>
//                                 <div className="form-group">

//                                     <label> Last Name: </label>
//                                     <input type="text" className="form-control" name="lastName"
//                                         value={this.state.fields.lastName} onChange={this.handleChange} />

//                                     <div className={this.state.errors.lastName ? 'alert alert-danger' : ''}>{this.state.errors.lastName}
//                                     </div>
//                                 </div>
//                                 <div className="form-group">

//                                     <label> Email: </label>
//                                     <input type="text" className="form-control" name="email"
//                                         value={this.state.fields.email} onChange={this.handleChange} />

//                                     <div className={this.state.errors.email ? 'alert alert-danger' : ''}>{this.state.errors.email}
//                                     </div>
//                                 </div>
//                                 <div className="form-group">

//                                     <label> Password: </label>
//                                     <input type="password" className="form-control" name="password"
//                                         value={this.state.fields.password} onChange={this.handleChange} />

//                                     <div className={this.state.errors.password ? 'alert alert-danger' : ''}>{this.state.errors.password}
//                                     </div>
//                                 </div>


//                                 <div className="form-group">
//                                     <input type="submit" value="Register" className="btn btn-primary" /> &nbsp;&nbsp;
//                     {/* <button type="button"  onClick={this.clearForm} className="btn btn-danger" >Clear</button> */}
//                                 </div>

//                             </form>

//                         </div>
//                     </div>
//                 </div>
//             </div>
//         )
//     }

// }



import React from 'react';
import axios from 'axios';
import Form from 'react-validation/build/form';
import Input from 'react-validation/build/input';
import { isEmail } from 'validator';
import NotificationSystem from 'react-notification-system';
import { NavLink } from 'react-router-dom';
import  Navbar  from './nav.component';
import Footer from './footer.component';
import { Icon } from 'semantic-ui-react';
import { Button } from 'semantic-ui-react';


const required = (value, props) => {
    if (!value || (props.isCheckable && !props.checked)) {
        return <span className="form-error is-visible">Required</span>;
    }
};

const email = (value) => {
    if (!isEmail(value)) {
        return <span className="form-error is-visible">${value} is not a valid email.</span>;
    }
};

const isEqual = (value, props, components) => {
    const bothUsed = components.password[0].isUsed && components.confirm[0].isUsed;
    const bothChanged = components.password[0].isChanged && components.confirm[0].isChanged;

    if (bothChanged && bothUsed && components.password[0].value !== components.confirm[0].value) {
        return <span className="form-error is-visible">Passwords are not equal.</span>;
    }
};


class Register extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            email: '',
            password: '',
            confirm: '',
            error: ''

        };
    }

    _notificationSystem = null

    _addNotification = (level, msg) => {

        this._notificationSystem.addNotification({
            message: msg,
            level: level
        });
    }

    componentDidMount() {
        this._notificationSystem = this.refs.notificationSystem;

    }

    getRegister = (e) => {
        e.preventDefault();
        axios.post('http://localhost:4000/users/register', this.state).then(res => {

            console.log(res.data);
            window.alert("You Have successfully registered");
            // this._addNotification("success", "You have successfully registered.");
            window.location = '/login';

        })
            .catch(err => {
                console.log(err)
                console.error(err.response);
                var errors = err.response.data.errors === undefined ? [] : err.response.data.errors;

                for (var i = 0; i < errors.length; i++) {
                    this._addNotification("error", `${i + 1} -> ${errors[i].param}: ${errors[i].msg}`)
                }


            });

    }

    render() {
        return (
            <div>
                 <Navbar />
                <div style={{backgroundColor:" cornsilk"}}>
                   <div className="row">
                <div className="offset-lg-3 col-lg-6" style={{ marginTop: 20 }}><center><i className="fas fa-user-circle fa-7x" ><h2>Register</h2></i></center>

                            <Form method="POST" onSubmit={this.getRegister}>

                                <div className="form-group" id="iconlogin" >
                                <label><Icon
                                        className="mail" size="big"></Icon>Email ID:</label>
                                    <Input type="email" className="form-control"
                                        value={this.state.email}
                                        onChange={(e) => { this.setState({ email: e.target.value }) }}
                                        name="email" id="Email1" required
                                        validations={[required, email]}
                                        aria-describedby="emailHelp" placeholder="Enter email" />
                                    <small id="emailHelp" className="form-text text-muted">We'll never share your email with anyone else.</small>
                                </div>
                                <div className="form-group" id="iconlogin2">
                                <label><Icon className="secret user" size="big"></Icon>Password:</label>
                                    <Input type="password"
                                        value={this.state.password}
                                        onChange={(e) => { this.setState({ password: e.target.value }) }}
                                        className="form-control" name="password" id="password1" required
                                        validations={[required, isEqual]}
                                        placeholder="Password" />
                                </div>
                                <div className="form-group" id="iconlogin2" >
                                <label><Icon className="secret user" size="big"></Icon>Confirm Password:</label>
                                    <Input type="password"
                                        value={this.state.password2} required
                                        onChange={(e) => { this.setState({ confirm: e.target.value }) }}
                                        className="form-control" name="confirm" 
                                        validations={[required, isEqual]}
                                        id="repeatpassword" placeholder="Confirm Password" />
                                </div>


                                {/* <button type="submit" className="btn btn-outline-secondary btn-block" >Create</button> */}

                                 <Button inverted color='purple' type="submit" align="center">
        Create 
      </Button>
                            </Form>

                        </div>

                    </div>
                </div>
                <NotificationSystem ref="notificationSystem" />
                <hr />
                <br />
              < Footer />
            </div>

        );
    }
}

export default Register;