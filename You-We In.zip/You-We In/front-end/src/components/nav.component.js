import React from 'react';
import {Link} from 'react-router-dom'
import '../App.css';
import { Icon } from 'semantic-ui-react';

export default class NavBar extends React.Component {
    render() {
        return (
            <div>
                <nav className="navbar navbar-expand-lg " style={{ backgroundColor: "#009688" }}>
                <a className="navbar-brand" href="/home" rel="noopener noreferrer" target="_blank">
            <img src='../images/logo1.png' width="50" height="60" alt="logo is missing" />
          </a>
                    <Link to="/"
                        className="navbar-brand text-light"><h2><b>YouWe-In</b></h2></Link>
                    <button className="navbar-toggler" type="button" data-toggle="collapse"
                        data-target="#collapsibleNavbar">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="collapsibleNavbar">
                        <ul className="navbar-nav mr-auto">
                            <li className="navbar-item ">
                                <Link to="/home" className="nav-link text-light"><h5><Icon
                                 className="home" size="big"></Icon><b>Home</b></h5></Link>
                            </li>
                        </ul>
                        <ul className="navbar-nav ml-auto">
                            <li className="nav-item">
                                <a className="nav-link text-light" href="login"><h5><Icon
                                 className="sign-in" size="big"></Icon><b>Login</b></h5></a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link text-light" href="register"><h5><Icon className="signup"
                                size="big"></Icon><b>Register</b></h5></a>
                            </li>

                        </ul>

                    </div>
                </nav>


            </div>

        )
    }
}