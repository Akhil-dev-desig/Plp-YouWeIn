import React from 'react';
import Footer from './footer.component';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import { Form, Icon } from 'semantic-ui-react';
import NotificationSystem from 'react-notification-system';

import Navbar from './nav.component';
class Login extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            email: '',
            password: ''
        }
    }
    _notificationSystem = null
    _addNotification = (level, msg) => {
        this._notificationSystem.addNotification({
            message: msg,
            level: level
        });
    }

    componentDidMount() {
        this._notificationSystem = this.refs.notificationSystem;

    }

    getLogIn = (e) => {
        e.preventDefault();
        axios.post('http://localhost:4000/users/login', this.state).then(res => {
            console.log(res.data);
            window.alert("You Have successfully Logged In");
            this._addNotification("success", "You have successfully LogIn.");
            if (res.status === 200) {
                console.log(res.data);
                localStorage.setItem("UserObject", JSON.stringify(res.data));
                window.location = '/addprofile';
            }
        })
            .catch(err => {
                console.log(err)
                console.log(err.response.data.msg);
                if (err.response.status === 401) {
                    this._addNotification("error", `${err.response.data.msg}`);
                }
                console.error(err.response);
                var errors = err.response.data.errors === undefined ? [] : err.response.data.errors;

                for (var i = 0; i < errors.length; i++) {
                    this._addNotification("error", `${i + 1} -> ${errors[i].param}: ${errors[i].msg}`)
                }
            });
    }
    render() {
        return (
            <div>
                <Navbar />
                <div style={{ backgroundColor: "mistyrose" }}>
                    <div className="row" >
                        <div className="offset-lg-3 col-lg-6" style={{ marginTop: 20 }}><center><i className="fas fa-user-circle fa-7x" ></i></center>
                            <h2 className="text-center text-shadow">Login</h2><br />
                            <Form method="POST" onSubmit={this.getLogIn}>

                                <div className="field">
                                    <label><Icon
                                        className="mail" size="big"></Icon>Email ID:</label>
                                    <div className="ui left icon input">
                                        <input type="email"
                                            value={this.state.email}
                                            onChange={(e) => { this.setState({ email: e.target.value }) }}
                                            className="form-control" name="email" id="email" required aria-describedby="emailHelp" placeholder="Enter email" />
                                        <i aria-hidden="true" className="envelope icon"></i>
                                    </div>
                                </div>

                                <div className="field">
                                    <label><Icon className="secret user" size="big"></Icon>Password:</label>
                                    <div className="ui left icon input">
                                        <input type="password"
                                            value={this.state.password}
                                            onChange={(e) => { this.setState({ password: e.target.value }) }}
                                            className="form-control" name="password" required id="password" placeholder="Password" />
                                        <i aria-hidden="true" className="lock icon"></i>
                                    </div>

                                </div>
                          
                                <button className="ui blue inverted button" type="submit">Submit</button>
                                <br />

                                <center>
                                    <NavLink to='/register'>
                                        <button className="ui violet inverted button">New User? Register Here</button>
                                    </NavLink>
                                </center>
                            </Form>

                        </div>
                    </div>
                    <NotificationSystem ref="notificationSystem" />

                </div>
                <br />
                <Footer />
            </div>
        )
    }
}

export default Login;
